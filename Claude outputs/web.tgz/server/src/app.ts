import Fastify, { type FastifyInstance, type FastifyRequest } from "fastify";
import helmet from "@fastify/helmet";
import cookie from "@fastify/cookie";
import cors from "@fastify/cors";
import rateLimit from "@fastify/rate-limit";
import multipart from "@fastify/multipart";
import { randomUUID, timingSafeEqual } from "node:crypto";
import { runSweep } from "./lib/sweep.js";
import { createRateLimitStore, createRestCounter } from "./lib/ratelimit-store.js";
import { setLimiterBackend } from "./lib/limiter.js";
import type { Config } from "./lib/config.js";
import type { Db } from "./lib/db.js";
import { AppError } from "./lib/errors.js";
import { authRoutes, meRoutes } from "./modules/auth/routes.js";
import { socialRoutes } from "./modules/auth/social-routes.js";
import { adminRoutes } from "./modules/admin/routes.js";
import { adminSellerRoutes, sellerRoutes } from "./modules/sellers/routes.js";
import { adminCatalogueRoutes, publicCatalogueRoutes, sellerCatalogueRoutes } from "./modules/catalogue/routes.js";
import { createFieldCipher, type FieldCipher } from "./lib/encryption.js";
import { createStorage, type Storage } from "./lib/storage.js";
import { PostgresSearch, type SearchService } from "./modules/search/service.js";
import { adminInventoryRoutes, sellerInventoryRoutes } from "./modules/inventory/routes.js";
import { adminCouponRoutes, adminPricingRoutes, cartRoutes, wishlistRoutes } from "./modules/cart/routes.js";
import { adminReturnRoutes, buyerReturnRoutes, sellerReturnRoutes } from "./modules/returns/routes.js";
import { adminPaymentRoutes, paymentRoutes, paymentWebhookRoutes } from "./modules/payments/routes.js";
import { adminCommissionRoutes, adminFinanceRoutes, sellerFinanceRoutes } from "./modules/finance/routes.js";
import { safetyRoutes, adminReportRoutes } from "./modules/safety/routes.js";
import { chatRoutes } from "./modules/chat/routes.js";
import { adminRatingRoutes, publicRatingRoutes, ratingRoutes } from "./modules/ratings/routes.js";
import { addressRoutes, adminOrderRoutes, orderRoutes, sellerOrderRoutes } from "./modules/orders/routes.js";

declare module "fastify" {
  interface FastifyInstance {
    cfg: Config;
    db: Db;
    cipher: FieldCipher;
    storage: Storage;
    searchService: SearchService;
  }
}

export async function buildApp(cfg: Config, db: Db, overrides: { storage?: Storage } = {}): Promise<FastifyInstance> {
  const app = Fastify({
    logger: {
      level: cfg.LOG_LEVEL,
      // Never log credentials, tokens or cookies.
      redact: ["req.headers.authorization", "req.headers.cookie", "res.headers['set-cookie']", "*.password", "*.token"],
    },
    trustProxy: cfg.TRUST_PROXY_HOPS > 0 ? (_addr: string, hop: number) => hop < cfg.TRUST_PROXY_HOPS : false,
    bodyLimit: 1_048_576,
    // Always server-generated, because it is stored in audit rows; a client id is only logged.
    genReqId: () => randomUUID(),
  });

  app.decorate("cfg", cfg);
  app.decorate("db", db);
  app.decorate("cipher", createFieldCipher(cfg));
  app.decorate("storage", overrides.storage ?? createStorage(cfg));
  app.decorate("searchService", new PostgresSearch(db));
  app.decorateRequest("auth", null);
  app.decorateRequest("seller", null);

  await app.register(helmet, {
    contentSecurityPolicy: { directives: { defaultSrc: ["'none'"], frameAncestors: ["'none'"] } },
    hsts: cfg.NODE_ENV === "production" ? { maxAge: 31_536_000, includeSubDomains: true } : false,
  });
  await app.register(cors, {
    origin: cfg.corsOrigins,
    credentials: true,
    methods: ["GET", "POST", "PATCH", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With", "Idempotency-Key", "X-Request-Id", "X-Client"],
    maxAge: 600,
  });
  await app.register(cookie);
  // Only the document upload route reads multipart; limits are tightened again there.
  await app.register(multipart, { limits: { fileSize: 8 * 1024 * 1024, files: 1, fields: 0, parts: 2, headerPairs: 50 } });
  // Shared counters when UPSTASH_REDIS_REST_URL/_TOKEN are set (all serverless instances see the same count);
  // otherwise in-memory limits, per instance. Redis outages fall back to memory instead of blocking traffic.
  const counter = createRestCounter(cfg);
  setLimiterBackend(counter);
  await app.register(rateLimit, {
    ...(counter ? { store: createRateLimitStore(counter, (m) => app.log.warn(m)) as never } : {}),
    global: true,
    max: 300,
    timeWindow: "1 minute",
    hook: "preHandler",
    errorResponseBuilder: (_req, ctx) => new AppError(429, "RATE_LIMITED", `Too many requests. Try again in ${Math.ceil(ctx.ttl / 1000)} seconds.`),
  });

  app.addHook("onRequest", async (req) => {
    const client = req.headers["x-request-id"];
    if (typeof client === "string" && client.length <= 64) req.log.info({ clientRequestId: client }, "client request id");
  });

  app.addHook("onSend", async (req, reply) => {
    reply.header("x-request-id", req.id);
    // Default: never cache API responses. Routes that serve public media set their own policy.
    if (!reply.hasHeader("cache-control")) reply.header("cache-control", "no-store");
  });

  app.setNotFoundHandler((req, reply) => {
    reply.code(404).send({ error: { code: "NOT_FOUND", message: "Route not found.", requestId: req.id } });
  });

  app.setErrorHandler((err: any, req, reply) => {
    const requestId = String(req.id);
    if (err instanceof AppError) {
      if (err.status >= 500) req.log.error({ err }, err.message);
      return reply.code(err.status).send({ error: { code: err.code, message: err.message, details: err.details, requestId } });
    }
    // Fastify's own client errors (bad JSON, body too large, wrong content type).
    if (typeof err?.statusCode === "number" && err.statusCode >= 400 && err.statusCode < 500) {
      const code = err.statusCode === 413 ? "PAYLOAD_TOO_LARGE" : err.statusCode === 415 ? "UNSUPPORTED_MEDIA_TYPE" : "BAD_REQUEST";
      return reply.code(err.statusCode).send({ error: { code, message: "The request could not be read.", requestId } });
    }
    // Two transactions collided (deadlock or serialization failure). Nothing was saved; retrying works.
    if (err?.code === "40P01" || err?.code === "40001") {
      req.log.warn({ err }, "transaction conflict");
      return reply.code(503).header("retry-after", "1").send({ error: { code: "TRY_AGAIN", message: "Too many people are changing this at once. Please try again.", requestId } });
    }
    // Postgres invalid input (for example a malformed id in a cursor).
    if (typeof err?.code === "string" && err.code.startsWith("22")) {
      return reply.code(400).send({ error: { code: "VALIDATION_FAILED", message: "Some values are invalid.", requestId } });
    }
    req.log.error({ err }, "unhandled error");
    // Diagnostic header: off unless DEBUG_DIAGNOSTICS=true (it echoes the error message to the caller). Never enable it in production.
    if (cfg.DEBUG_DIAGNOSTICS === "true") reply.header("x-debug-error", (String(err?.code ?? err?.name ?? "error") + ": " + String(err?.message ?? "")).replace(/[^\x20-\x7e]/g, " ").slice(0, 120));
    return reply.code(500).send({ error: { code: "INTERNAL", message: "Something went wrong on our side. Please try again.", requestId } });
  });

  app.get("/health", { config: { rateLimit: false } }, async () => ({ status: "ok" }));
  // Diagnostic (see DEBUG_DIAGNOSTICS): tells the caller which address the API sees for them.
  const debugClientIp = async (req: FastifyRequest) => ({
    ip: req.ip, socket: req.socket.remoteAddress,
    xForwardedFor: req.headers["x-forwarded-for"] ?? null, xRealIp: req.headers["x-real-ip"] ?? null, xVercelForwardedFor: req.headers["x-vercel-forwarded-for"] ?? null,
    trustProxyHops: cfg.TRUST_PROXY_HOPS, poolMax: cfg.DATABASE_POOL_MAX,
  });
  // Off unless DEBUG_DIAGNOSTICS=true: it reveals the caller's address and proxy headers to anyone.
  if (cfg.DEBUG_DIAGNOSTICS === "true") {
    app.get("/debug/client-ip", { config: { rateLimit: false } }, debugClientIp);
    app.get("/api/v1/debug/client-ip", { config: { rateLimit: false } }, debugClientIp);
  }

  // Background housekeeping for serverless hosting, called every minute by a scheduler
  // (Supabase pg_cron). Only exists when CRON_SECRET is set; the secret is compared in constant time.
  if (cfg.CRON_SECRET) {
    const expected = Buffer.from(`Bearer ${cfg.CRON_SECRET}`);
    app.post("/internal/sweep", { config: { rateLimit: false } }, async (req, reply) => {
      const got = Buffer.from(String(req.headers.authorization ?? ""));
      if (got.length !== expected.length || !timingSafeEqual(got, expected)) {
        return reply.code(401).send({ error: { code: "UNAUTHENTICATED", message: "Not allowed.", requestId: req.id } });
      }
      return { ok: true, result: await runSweep(db, cfg, req.log) };
    });
  }
  app.get("/ready", { config: { rateLimit: false } }, async (_req, reply) => {
    try {
      await db.query("select 1");
      return { status: "ready" };
    } catch {
      return reply.code(503).send({ error: { code: "NOT_READY", message: "Database unavailable." } });
    }
  });

  await app.register(async (v1) => {
    await v1.register(authRoutes, { prefix: "/auth" });
    await v1.register(socialRoutes, { prefix: "/auth/social" });
    await v1.register(meRoutes, { prefix: "/me" });
    await v1.register(adminRoutes, { prefix: "/admin" });
    await v1.register(sellerRoutes, { prefix: "/seller" });
    await v1.register(adminSellerRoutes, { prefix: "/admin/sellers" });
    await v1.register(sellerCatalogueRoutes, { prefix: "/seller/products" });
    await v1.register(adminCatalogueRoutes, { prefix: "/admin/catalogue" });
    await v1.register(publicCatalogueRoutes, { prefix: "/catalogue" });
    await v1.register(sellerInventoryRoutes, { prefix: "/seller/inventory" });
    await v1.register(adminInventoryRoutes, { prefix: "/admin/inventory" });
    await v1.register(cartRoutes, { prefix: "/cart" });
    await v1.register(wishlistRoutes, { prefix: "/me/wishlist" });
    await v1.register(adminCouponRoutes, { prefix: "/admin/coupons" });
    await v1.register(adminPricingRoutes, { prefix: "/admin/pricing" });
    await v1.register(addressRoutes, { prefix: "/me/addresses" });
    await v1.register(orderRoutes);
    await v1.register(sellerOrderRoutes, { prefix: "/seller/orders" });
    await v1.register(adminOrderRoutes, { prefix: "/admin" });
    await v1.register(adminCommissionRoutes, { prefix: "/admin/commission" });
    await v1.register(adminFinanceRoutes, { prefix: "/admin/finance" });
    await v1.register(sellerFinanceRoutes, { prefix: "/seller/finance" });
    await v1.register(paymentRoutes);
    await v1.register(paymentWebhookRoutes, { prefix: "/payments/webhook" });
    await v1.register(adminPaymentRoutes, { prefix: "/admin/payments" });
    await v1.register(chatRoutes, { prefix: "/chat" });
    await v1.register(ratingRoutes, { prefix: "/ratings" });
    await v1.register(publicRatingRoutes, { prefix: "/catalogue/sellers" });
    await v1.register(adminRatingRoutes, { prefix: "/admin/ratings" });
    await v1.register(safetyRoutes, { prefix: "/safety" });
    await v1.register(adminReportRoutes, { prefix: "/admin/reports" });
    await v1.register(buyerReturnRoutes);
    await v1.register(sellerReturnRoutes, { prefix: "/seller" });
    await v1.register(adminReturnRoutes, { prefix: "/admin" });
  }, { prefix: "/api/v1" });

  return app;
}
