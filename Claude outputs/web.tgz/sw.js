// seller.js and admin.js are not precached: shoppers never need them. They are cached the first time a seller or admin opens them.
const V="reloved-v34",SHELL=["./","index.html","theme.js","styles.css","app.js","swipe.js","showcase.js","safety.js","social.js","api.js","config.js","manifest.webmanifest","icon-192.png","icon-512.png"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener("fetch",e=>{
  const u=new URL(e.request.url);
  // Only the app's own files are cached. API calls (private data, prices, stock) always go to the network.
  if(e.request.method!=="GET"||u.origin!==location.origin||u.pathname.startsWith("/api/"))return;
  // Offline, only page loads fall back to index.html; a missing script must fail as a script, not run the HTML page as code.
  e.respondWith(fetch(e.request).then(r=>{if(r.ok){const c=r.clone();caches.open(V).then(x=>x.put(e.request,c))}return r}).catch(()=>caches.match(e.request).then(r=>r||(e.request.mode==="navigate"?caches.match("index.html"):Response.error()))));
});
